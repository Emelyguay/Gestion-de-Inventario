
const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres', // <-- CAMBIA ESTO
    password: 'emely123',
    port: 5432,
});


module.exports = pool; // Exporta el pool directamente