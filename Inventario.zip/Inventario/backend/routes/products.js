const express = require('express');
const router = express.Router();
const { crearProducto, obtenerProductos } = require('../controllers/productController');

// Define las rutas para obtener y crear productos
router.get('/', obtenerProductos);
router.post('/', crearProducto);

module.exports = router;