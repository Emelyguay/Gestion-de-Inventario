// En tu archivo de rutas (ej: routes/dashboard.js)

const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/auth'); // <-- Importas el guardia

// Esta ruta ahora está protegida. 
// `verifyToken` se ejecutará primero. Si el token es válido, se ejecutará la lógica de la ruta.
router.get('/datos-protegidos', verifyToken, (req, res) => {
  // Gracias al middleware, ahora tenemos acceso a req.user
  res.json({ 
    message: '¡Bienvenido a la sección protegida!',
    usuario: req.user 
  });
});

module.exports = router;