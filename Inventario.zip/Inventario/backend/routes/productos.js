const express = require('express');
const router = express.Router();
const { getAllProductos } = require('../controllers/productoController');
const verifyToken = require('../middleware/auth'); // <-- ¡Importamos el guardia de seguridad!

// Aplicamos el middleware 'verifyToken' a esta ruta.
// Nadie podrá acceder a /api/productos sin un token válido.
router.get('/', verifyToken, getAllProductos);

module.exports = router;