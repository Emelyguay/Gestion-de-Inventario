// middleware/auth.js

const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'secreto123';

const verifyToken = (req, res, next) => {
  // 1. Buscamos el token en los headers de la petición
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Formato "Bearer TOKEN"

  if (!token) {
    // 2. Si no hay token, el acceso es denegado
    return res.status(403).json({ message: 'Acceso denegado: No se proporcionó un token.' });
  }

  // 3. Verificamos que el token sea válido
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido o expirado.' });
    }

    // Si el token es válido, guardamos los datos del usuario en la petición
    req.user = decoded;
    next(); // ¡Importante! Permite que la petición continúe hacia la ruta final
  });
};

module.exports = verifyToken;