const express = require('express');
const cors = require('cors');

const productRoutes = require('./routes/products');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Mensaje para confirmar que la conexión fue exitosa desde el pool
const pool = require('./config/db');
pool.on('connect', () => {
    console.log('✅ Conexión a la base de datos establecida correctamente.');
});

app.use('/api/products', productRoutes);

app.listen(PORT, () => {
    console.log(`🚀 Servidor simple corriendo en http://localhost:${PORT}`);
});