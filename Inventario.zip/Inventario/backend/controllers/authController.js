const pool = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');


// Es una buena práctica tener la clave secreta en un archivo .env
const SECRET = process.env.JWT_SECRET || 'secreto123';

// Tu función de login está perfecta, no necesita cambios.
const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await pool.query('SELECT * FROM usuarios WHERE email = $1', [email]);
    const usuario = result.rows[0];

    if (!usuario) {
      return res.status(401).json({ message: 'Usuario no encontrado' });
    }

    const match = await bcrypt.compare(password, usuario.password);
    if (!match) {
      return res.status(401).json({ message: 'Contraseña incorrecta' });
    }

    const token = jwt.sign({ id: usuario.id, email: usuario.email }, SECRET, { expiresIn: '1h' });
    res.json({ token, nombre: usuario.nombre });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error en el servidor' });
  }
};


// ========= FUNCIÓN DE REGISTRO MEJORADA =========
const registrar = async (req, res) => {
  const { nombre, email, password } = req.body;

  // Se añade un bloque try...catch para manejar errores inesperados
  try {
    // 1. (NUEVO) Verificar si el correo ya existe en la base de datos
    const userExists = await pool.query('SELECT * FROM usuarios WHERE email = $1', [email]);
    
    if (userExists.rows.length > 0) {
      // Si encontramos un usuario, devolvemos un error
      return res.status(400).json({ message: 'El correo electrónico ya está en uso.' });
    }

    // 2. Hashear la contraseña (esto ya lo tenías y está bien)
    const hashedPassword = await bcrypt.hash(password, 10);

    // 3. Insertar el nuevo usuario
    await pool.query(
      'INSERT INTO usuarios (nombre, email, password) VALUES ($1, $2, $3)',
      [nombre, email, hashedPassword]
    );
    
    // 4. Enviar una respuesta de éxito más clara
    res.status(201).json({ message: 'Usuario registrado exitosamente.' });

  } catch (error) {
    // Si algo sale mal (ej: error de conexión con la BD), se captura aquí
    console.error("Error al registrar usuario:", error);
    res.status(500).json({ message: 'Error en el servidor al registrar el usuario.' });
  }
};

module.exports = { login, registrar };