const pool = require('../config/db');

// Obtener todos los usuarios
const getUsers = async (req, res) => {
  const result = await pool.query('SELECT * FROM usuarios ORDER BY id ASC');
  res.json(result.rows);
};

// Crear nuevo usuario
const createUser = async (req, res) => {
  const { nombre, email } = req.body;
  await pool.query('INSERT INTO usuarios (nombre, email) VALUES ($1, $2)', [nombre, email]);
  res.json({ message: 'Usuario creado' });
};

// Actualizar usuario
const updateUser = async (req, res) => {
  const { id } = req.params;
  const { nombre, email } = req.body;
  await pool.query('UPDATE usuarios SET nombre=$1, email=$2 WHERE id=$3', [nombre, email, id]);
  res.json({ message: 'Usuario actualizado' });
};

// Eliminar usuario
const deleteUser = async (req, res) => {
  const { id } = req.params;
  await pool.query('DELETE FROM usuarios WHERE id=$1', [id]);
  res.json({ message: 'Usuario eliminado' });
};

module.exports = { getUsers, createUser, updateUser, deleteUser };
