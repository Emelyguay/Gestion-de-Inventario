const pool = require('../config/db'); // Importa el pool de conexión

// Crear un nuevo producto
exports.crearProducto = async (req, res) => {
    const { nombre, descripcion, precio, stock } = req.body;
    try {
        const result = await pool.query(
            'INSERT INTO productos (nombre, descripcion, precio, stock) VALUES ($1, $2, $3, $4) RETURNING *',
            [nombre, descripcion, precio, stock]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error("Error al crear producto:", error);
        res.status(500).send('Error en el Servidor al crear.');
    }
};

// Obtener todos los productos
exports.obtenerProductos = async (req, res) => {
    try {
        const { rows } = await pool.query('SELECT * FROM productos ORDER BY id ASC');
        res.json(rows);
    } catch (error) {
        console.error("Error al obtener productos:", error);
        res.status(500).send('Error en el Servidor al obtener.');
    }
};