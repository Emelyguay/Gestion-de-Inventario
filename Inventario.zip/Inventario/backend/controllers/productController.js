const pool = require('../config/db');

const getProductos = async (req, res) => {
  const result = await pool.query('SELECT * FROM productos ORDER BY id ASC');
  res.json(result.rows);
};

const createProducto = async (req, res) => {
  const { nombre, precio, stock } = req.body;
  await pool.query('INSERT INTO productos (nombre, precio, stock) VALUES ($1, $2, $3)', [nombre, precio, stock]);
  res.json({ message: 'Producto agregado' });
};

const updateProducto = async (req, res) => {
  const { id } = req.params;
  const { nombre, precio, stock } = req.body;
  await pool.query('UPDATE productos SET nombre=$1, precio=$2, stock=$3 WHERE id=$4', [nombre, precio, stock, id]);
  res.json({ message: 'Producto actualizado' });
};

const deleteProducto = async (req, res) => {
  const { id } = req.params;
  await pool.query('DELETE FROM productos WHERE id=$1', [id]);
  res.json({ message: 'Producto eliminado' });
};

module.exports = { getProductos, createProducto, updateProducto, deleteProducto };
