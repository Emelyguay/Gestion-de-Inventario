document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        if (username.trim()) {
            localStorage.setItem('loggedInUser', username);
            window.location.href = 'productos.html';
        }
    });
});