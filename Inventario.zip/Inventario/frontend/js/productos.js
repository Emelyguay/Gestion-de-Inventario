document.addEventListener('DOMContentLoaded', () => {
    const productForm = document.getElementById('product-form');
    const productsTableBody = document.getElementById('products-table-body');
    const logoutBtn = document.getElementById('logoutBtn');
    const apiURL = 'http://localhost:3000/api/products';

    const fetchProducts = async () => {
        const response = await fetch(apiURL);
        const products = await response.json();
        productsTableBody.innerHTML = '';
        products.forEach(product => {
            const row = document.createElement('tr');
            row.innerHTML = `<td>${product.id}</td><td>${product.nombre}</td><td>${product.precio}</td><td>${product.stock}</td>`;
            productsTableBody.appendChild(row);
        });
    };

    productForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newProduct = {
            nombre: document.getElementById('nombre').value,
            descripcion: document.getElementById('descripcion').value,
            precio: parseFloat(document.getElementById('precio').value),
            stock: parseInt(document.getElementById('stock').value)
        };
        await fetch(apiURL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(newProduct),
        });
        productForm.reset();
        fetchProducts();
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('loggedInUser');
        window.location.href = 'index.html';
    });

    fetchProducts();
});