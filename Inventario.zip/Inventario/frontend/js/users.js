const API_URL = 'http://localhost:3000/api/usuarios';
const tabla = document.getElementById('tablaUsuarios');
const btnNuevo = document.getElementById('btnNuevo');
const busqueda = document.getElementById('busqueda');

let usuarios = [];

const cargarUsuarios = async () => {
  const res = await fetch(API_URL);
  usuarios = await res.json();
  mostrarUsuarios(usuarios);
};

const mostrarUsuarios = (lista) => {
  tabla.innerHTML = '';
  lista.forEach(user => {
    tabla.innerHTML += `
      <tr>
        <td>${user.id}</td>
        <td>${user.nombre}</td>
        <td>${user.email}</td>
        <td>
          <button class="btn btn-warning btn-sm" onclick="editarUsuario(${user.id})">✏️</button>
          <button class="btn btn-danger btn-sm" onclick="eliminarUsuario(${user.id})">🗑️</button>
        </td>
      </tr>
    `;
  });
};

const eliminarUsuario = async (id) => {
  if (confirm('¿Eliminar este usuario?')) {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    cargarUsuarios();
  }
};

const editarUsuario = async (id) => {
  const usuario = usuarios.find(u => u.id === id);
  const nuevoNombre = prompt('Editar nombre:', usuario.nombre);
  const nuevoEmail = prompt('Editar email:', usuario.email);

  if (nuevoNombre && nuevoEmail) {
    await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: nuevoNombre, email: nuevoEmail })
    });
    cargarUsuarios();
  }
};

btnNuevo.addEventListener('click', async () => {
  const nombre = prompt('Nombre del usuario:');
  const email = prompt('Correo del usuario:');

  if (nombre && email) {
    await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, email })
    });
    cargarUsuarios();
  }
});

busqueda.addEventListener('input', () => {
  const filtro = busqueda.value.toLowerCase();
  const filtrados = usuarios.filter(u =>
    u.nombre.toLowerCase().includes(filtro) || u.email.toLowerCase().includes(filtro)
  );
  mostrarUsuarios(filtrados);
});

cargarUsuarios();
